# Python-Keylogger

A simple keylogger built using the pynput library. This logger does not attempt to open any internet connections. This keylogger only logs your inputs while it is running and dumps those into a file called log.txt located in the program's source directory. This keylogger is 100% safe to run and experiment with.

### Instructions

1. Install pynput:

```pip install pynput```

2. Run the keylogger:

```python keylogger.py```

Requires Python 3+